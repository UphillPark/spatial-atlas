import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,cp,writeFile,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
test('content files drive the generated site through edit, add, delete and relation changes',async()=>{
 const parent=path.resolve(tmpdir()),fixture=await mkdtemp(path.join(parent,'atlas-test-'));
 const source=fileURLToPath(new URL('../',import.meta.url));
 try{
  for(const dir of ['scripts','public','content'])await cp(path.join(source,dir),path.join(fixture,dir),{recursive:true});
  const build=async()=>{execFileSync(process.execPath,[path.join(fixture,'scripts/build.mjs')]);return JSON.parse(await readFile(path.join(fixture,'dist/data.json'),'utf8'));};
  const projectPath=path.join(fixture,'content/projects/shared-ground.json');
  const original=JSON.parse(await readFile(projectPath,'utf8'));
  await writeFile(projectPath,JSON.stringify({...original,title:'편집 반영 확인',related:['verification']}));
  const added=path.join(fixture,'content/projects/verification.json');
  await writeFile(added,JSON.stringify({id:'verification',title:'추가 확인',year:'2026',category:'검증',blocks:[],related:[]}));
  let output=await build();
  assert.equal(output.projects.length,4);
  assert.equal(output.projects.find(p=>p.id==='shared-ground').title,'편집 반영 확인');
  assert(output.edges.some(([a,b])=>a==='shared-ground'&&b==='verification'));
  await rm(added);
  output=await build();
  assert.equal(output.projects.length,3);
  assert(!output.edges.flat().includes('verification'));
  assert.deepEqual(output.projects.find(p=>p.id==='shared-ground').related,[]);
  const html=await readFile(path.join(fixture,'dist/index.html'),'utf8');
  assert(html.includes('app.js'));assert(html.includes('atlas.css'));
 }finally{
  if(path.dirname(fixture)!==parent||!path.basename(fixture).startsWith('atlas-test-'))throw new Error('Unexpected test directory');
  await rm(fixture,{recursive:true,force:true});
 }
});
