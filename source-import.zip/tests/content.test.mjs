import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizeProjects,graphEdges} from '../scripts/content.mjs';
const a={id:'one',title:'원본',year:'2026',category:'설계',related:['two','missing','one']};
const b={id:'two',title:'둘',year:'2025',category:'기록',related:['one']};
test('edits and additions flow through the same public data',()=>{
 const result=normalizeProjects([{...a,title:'수정한 제목'},b]);
 assert.equal(result[0].title,'수정한 제목');assert.equal(result.length,2);
 assert.deepEqual(graphEdges(result),[['one','two']]);
});
test('deleting or hiding projects removes dangling graph edges',()=>{
 assert.deepEqual(normalizeProjects([a])[0].related,[]);
 assert.deepEqual(graphEdges(normalizeProjects([a,{...b,published:false}])),[]);
});
test('changing relationships updates edges and reciprocal edges are deduplicated',()=>{
 assert.deepEqual(graphEdges(normalizeProjects([a,b])),[['one','two']]);
 assert.deepEqual(graphEdges(normalizeProjects([{...a,related:[]},{...b,related:[]}])),[]);
});
test('duplicate and malformed IDs fail build clearly',()=>{
 assert.throws(()=>normalizeProjects([a,a]),/Duplicate/);
 assert.throws(()=>normalizeProjects([{...a,id:'bad id'}]),/Invalid/);
});
