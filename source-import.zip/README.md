# UphillPark / Lee Joseph — Spatial Atlas

건축 설계·현장기록·리서치를 연결하는 정적 포트폴리오입니다. Node.js 22 이상만 필요하며 별도 패키지 설치나 유료 서비스는 필요 없습니다.

**현재 자료는 교체용 샘플입니다. 실제 수행한 프로젝트가 아닙니다.**

## 어디를 편집하나요?

| 원하는 변경 | 파일 |
| --- | --- |
| 이름·소개·외부 링크 | `content/site.json` |
| 프로젝트 하나 | `content/projects/작업-id.json` |
| 새 프로젝트 복사본 | `templates/project.json` |
| 사진·도면 파일 | `public/assets/` |
| 전체 페이지 디자인 | `public/style.css`, `public/atlas.css`, `public/app.js` |

글·사진·분류·작업 연결은 콘텐츠 파일에서 편집합니다. 전체 레이아웃은 코드로 관리하며 Framer처럼 자유롭게 드래그하여 디자인을 편집하는 기능은 없습니다.

## GitHub 웹에서 글 수정하기

1. 저장소의 `content/projects` 폴더에서 수정할 `.json` 파일을 엽니다.
2. 연필 아이콘 **Edit this file**을 누릅니다.
3. 제목(`title`), 연도(`year`), 짧은 설명(`summary`), 본문(`blocks` 안의 `text`)을 수정합니다.
4. **Commit changes**를 눌러 `main`에 저장합니다.
5. **Actions → Publish archive** 실행이 초록색으로 완료된 뒤 사이트를 새로고침합니다. 대개 몇 분이 걸리며 즉시 반영되지는 않습니다.

JSON은 문법이 엄격합니다. 큰따옴표와 쉼표를 유지하고, 마지막 항목 뒤에는 쉼표를 넣지 않습니다. 본문 줄바꿈은 `\n`, 본문 속 큰따옴표는 `\"`로 적습니다. 오류가 있으면 배포가 중단되어 마지막 정상 사이트가 유지됩니다. Actions의 빨간 실행에서 오류가 난 파일을 확인하고 수정합니다. 복구는 해당 파일의 History에서 이전 내용을 확인하여 새 커밋으로 되돌릴 수 있습니다.

## 프로젝트 추가하기

1. `templates/project.json`을 열고 전체 내용을 복사합니다.
2. `content/projects`에서 **Add file → Create new file**을 선택합니다.
3. `my-project.json`처럼 새 파일명을 입력하고 복사한 내용을 붙여 넣습니다.
4. `id`를 `my-project`처럼 **영문 소문자·숫자·하이픈만 사용한 고유 값**으로 바꿉니다. 기존 ID와 같으면 배포가 중단됩니다.
5. 제목, 본문, 연도, 분류를 바꾸고 저장합니다. 목록과 그래프에 자동 추가됩니다.

`featured: true`는 대표작입니다. 목록에서 먼저 표시되며 지도에는 채워진 점이 붙습니다. 카테고리는 자유롭게 작성할 수 있고 필터가 자동 생성됩니다. `sample: false`는 실제 작업임을 뜻합니다. 샘플을 전부 교체한 뒤 `site.json`의 `sampleMode`도 `false`로 바꿉니다.

## 사진·도면 업로드하기

1. `public/assets` 폴더에서 **Add file → Upload files**로 JPG, PNG, WebP, SVG 파일을 올립니다.
2. 파일명은 공백 없이 `project-plan.webp`처럼 작성합니다.
3. 프로젝트의 `cover` 또는 이미지 블록의 `src`에 `assets/project-plan.webp`를 적습니다. 앞에 `/`를 붙이지 않습니다.
4. `alt`에는 이미지 내용, `caption`에는 설명과 출처를 적습니다.

웹용 이미지 권장: 긴 변 1600–2400px, 가능하면 1장당 1MB 이하. 원본 대형 도면·PSD·비공개 자료는 올리지 마세요. `cover: ""`는 이미지 미등록 상태를 표시합니다.

## 본문 구성

`blocks` 배열의 순서가 페이지 순서입니다. 필요한 항목을 복사하거나 삭제합니다.

```json
{ "type": "text", "heading": "관찰", "text": "본문 첫 문단\n다음 문단" }
```

```json
{ "type": "image", "src": "assets/plan.webp", "alt": "1층 평면", "caption": "1층 평면 / 본인 작업" }
```

```json
{ "type": "pair", "images": [
  { "src": "assets/before.webp", "alt": "변경 전", "caption": "변경 전" },
  { "src": "assets/after.webp", "alt": "변경 후", "caption": "변경 후" }
] }
```

이미지 병치는 모바일에서 위아래로 쌓입니다.

## 관계 추가·삭제

`related`에 다른 작업의 `id`를 적습니다. 예: `"related": ["threshold-notes"]`.
두 작업 중 한쪽에만 적어도 선이 생기며 상세 페이지에는 서로 관련 작업으로 표시됩니다. 양쪽에 적었다면 연결을 완전히 제거할 때 양쪽에서 삭제합니다. 같은 카테고리라는 이유만으로 선을 자동 생성하지 않습니다.

프로젝트 파일을 삭제하거나 `published`를 `false`로 바꾸면 다음 배포에서 목록·그래프·상세에서 빠집니다. 남은 작업이 삭제된 ID를 참조해도 사이트는 깨지지 않습니다.

**공개 저장소의 `published: false`는 보안 기능이 아닙니다.** 원본 파일과 Git 기록은 공개됩니다. 비공개 자료는 처음부터 저장소에 넣지 마세요.

## 외부 링크와 임베드

`site.json` 또는 프로젝트의 `links`에 실제 주소를 넣습니다.

```json
{ "label": "네이버 블로그", "url": "https://blog.naver.com/실제아이디" }
```

임베드가 허용된 HTTPS 주소만 다음 블록으로 추가합니다. YouTube 등은 일반 공유 URL이 아닌 서비스가 제공하는 embed URL을 사용합니다.

```json
{ "type": "embed", "title": "인터랙티브 작업", "url": "https://example.com/embed/your-work" }
```

방문자가 불러오기 버튼을 눌러야 외부 콘텐츠가 로드됩니다. 네이버나 일부 서비스는 임베드를 차단할 수 있습니다. 그때는 함께 제공되는 새 탭 링크를 사용하세요. RSS 수집·자동 동기화는 없습니다.

## 배포 설정

1. GitHub 공개 저장소에 이 폴더의 내용을 올립니다. `content`, `public`, `scripts`, `templates`, `tests`, `package.json`, `.github/workflows/pages.yml`이 저장소 루트에 있어야 합니다.
2. **Settings → Pages → Build and deployment → Source → GitHub Actions**를 선택합니다.
3. **Actions → Publish archive → Run workflow → main**을 실행합니다.
4. 초록색 완료 표시와 Pages의 공개 주소를 확인합니다.

이 저장소 이름이 `spatial-atlas`이면 주소는 `https://UphillPark.github.io/spatial-atlas/`입니다. 공개 여부는 실제 배포 결과로 확인해야 합니다. 기본 주소와 공개 저장소를 사용하며 별도 도메인 비용은 없습니다.

GitHub 안내: https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages

## 로컬 실행과 검증

```sh
npm test
npm run build
npm start
```

`http://127.0.0.1:4173`을 엽니다. 편집 후 다시 `npm run build`하고 새로고침합니다. `dist`는 생성 결과이므로 직접 편집하지 않습니다. 외부 라이브러리·CMS·서버 DB는 없습니다.

테스트는 제목 수정, 작업 추가·삭제·비공개 전환, 관련 작업 변경, 중복 ID 방지를 확인합니다. 그래프는 직접 정렬된 2D 지도입니다. 노드 드래그, 배경 이동, 버튼·휠 확대축소, 카테고리 필터, 키보드 Enter로 작업 열기를 지원합니다. 물리 시뮬레이션이나 3D 기능은 없습니다.

## 오늘 이후

실제 대표작 1개를 먼저 입력해 이미지 비율과 설명의 밀도를 조정하세요. 도면·현장사진이 들어오기 전에는 시각 분위기의 완성도를 판단하는 데 한계가 있습니다. 이후 필요할 때 기존 콘텐츠 파일에 CMS를 연결할 수 있지만 현재는 GitHub 파일 편집 방식입니다.
